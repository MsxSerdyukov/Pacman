import pygame
import time
import math
import sys
import os
from threading import Timer
import random

T = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
     [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
     [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1],
     [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1],
     [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1],
     [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
     [1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1],
     [1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1],
     [1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1],
     [1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1],
     [2, 2, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2, 2],
     [2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2],
     [2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2],
     [1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1],
     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
     [1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1],
     [2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2],
     [2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2],
     [2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2],
     [1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1],
     [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
     [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1],
     [1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1],
     [1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1],
     [1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1],
     [1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1],
     [1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1],
     [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
     [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
     [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
     [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

all_sprites = pygame.sprite.Group()
fon = pygame.sprite.Group()
horizontal_borders = pygame.sprite.Group()
player_group = pygame.sprite.Group()
ghost_group = pygame.sprite.Group()


class Labirint(pygame.sprite.Sprite):
    def __init__(self, i, j):
        super().__init__(all_sprites)
        self.add(horizontal_borders)
        self.image = pygame.Surface([20, 20])
        self.rect = pygame.Rect(j * 20, i * 20, 20, 20)
        self.image.fill('blue')


class Ball(pygame.sprite.Sprite):  # игрок

    def __init__(self, radius, pl_x, pl_y, pl_t_x, pl_t_y):
        super().__init__(all_sprites, player_group)
        self.radius = radius
        self.pl_t_x = pl_t_x
        self.pl_t_y = pl_t_y
        self.pl_x = pl_x
        self.pl_y = pl_y
        self.vx = 10
        self.vy = 10

    def move(self):
        global monety
        if int(math.ceil(self.pl_x / 20) - 1) < 0 and napravlenie[0] == True:
            pygame.draw.rect(screen, (0, 0, 0), (self.pl_x, self.pl_y, 18, 18))
            if T[int(self.pl_y // 20)][self.pl_x // 20] == 0:
                T[int(self.pl_y // 20)][self.pl_x // 20] = 2
                monety -= 1
            self.pl_x = 540
            screen.blit(pacman_lft, (self.pl_x, self.pl_y))
        elif int(self.pl_x // 20 + 1) > 27 and napravlenie[2] == True:
            pygame.draw.rect(screen, (0, 0, 0), (self.pl_x, self.pl_y, 18, 18))
            if T[int(self.pl_y // 20)][self.pl_x // 20] == 0:
                T[int(self.pl_y // 20)][self.pl_x // 20] = 2
                monety -= 1
            self.pl_x = 0
            screen.blit(pacman_r, (self.pl_x, self.pl_y))
        elif napravlenie[0] == True and T[int(self.pl_y // 20)][
            int(math.ceil(self.pl_x / 20) - 1)] != 1 and self.pl_y % 20 == 0:
            pygame.draw.rect(screen, (0, 0, 0), (self.pl_x, self.pl_y, 18, 18))
            if T[int(self.pl_y // 20)][self.pl_x // 20] == 0:
                T[int(self.pl_y // 20)][self.pl_x // 20] = 2
                monety -= 1
            self.pl_x -= 10
            screen.blit(pacman_lft, (self.pl_x, self.pl_y))
        elif napravlenie[2] == True and T[int(self.pl_y // 20)][int(self.pl_x // 20 + 1)] != 1 and self.pl_y % 20 == 0:
            pygame.draw.rect(screen, (0, 0, 0), (self.pl_x, self.pl_y, 18, 18))
            if T[int(self.pl_y // 20)][self.pl_x // 20] == 0:
                T[int(self.pl_y // 20)][self.pl_x // 20] = 2
                monety -= 1
            self.pl_x += 10
            print(self.pl_x)
            screen.blit(pacman_r, (self.pl_x, self.pl_y))
        elif napravlenie[1] == True and T[int(math.ceil(self.pl_y / 20) - 1)][
            int(self.pl_x // 20)] != 1 and self.pl_x % 20 == 0:
            pygame.draw.rect(screen, (0, 0, 0), (self.pl_x, self.pl_y, 18, 18))
            if T[int(self.pl_y // 20)][self.pl_x // 20] == 0:
                T[int(self.pl_y // 20)][self.pl_x // 20] = 2
                monety -= 1
            self.pl_y -= 10
            screen.blit(pacman_up, (self.pl_x, self.pl_y))
        elif napravlenie[3] == True and T[int(self.pl_y // 20 + 1)][int(self.pl_x // 20)] != 1 and self.pl_x % 20 == 0:
            pygame.draw.rect(screen, (0, 0, 0), (self.pl_x, self.pl_y, 18, 18))
            if T[int(self.pl_y // 20)][self.pl_x // 20] == 0:
                T[int(self.pl_y // 20)][self.pl_x // 20] = 2
                monety -= 1
            self.pl_y += 10
            screen.blit(pacman_dw, (self.pl_x, self.pl_y))


class Ghost(Ball):
    def __init__(self, pl_x, pl_y, pl_t_x, pl_t_y, gh_x, gh_y, g_t_x, g_t_y): #
        super().__init__(ghost_group, all_sprites, player_group, pl_x, pl_y)
        self.pl_x = pl_x #координаты х игрока на картинке
        self.pl_y = pl_y #координаты у игрока на картинке
        self.pl_t_x = pl_t_x #координаты х в списке Т
        self.pl_t_y = pl_t_y #координаты у в списке Т
        self.vx = 10
        self.vy = 10
        self.gh_x = gh_x #координаты х на картинке
        self.gh_y = gh_y # координаты у на картинке
        self.g_t_x = g_t_x #координата х в списке Т
        self.g_t_y = g_t_y # координата у в списке Т

    def move(self):
        a = random.choice((0, 1, 2, 3))
        if a == 0:
            self.drawing_dots(T[self.g_t_y][self.g_t_x - 1], 0)
        elif a == 1:
            self.drawing_dots(T[self.g_t_y - 1][self.g_t_x], 1)
        elif a == 2:
            self.drawing_dots(T[self.g_t_y][self.g_t_x + 1], 2)
        elif a == 3:
            self.drawing_dots(T[self.g_t_y + 1][self.g_t_x], 3)

    def appearing(self):  # появление призраков
        pygame.draw.rect(screen, (0, 0, 0), (220, 260, 18, 18))
        screen.blit(ghost_pink, (self.gh_x, self.gh_y))

    def first_appearing(self):
        screen.blit(ghost_pink, (220, 260))

    def drawing_dots(self, dot_or_blk, dest):  # просмотр точки и дальнейшего пути
        time.sleep(0.5)
        if dot_or_blk == 0:  # если с монеткой
            if dest == 0:  # лево
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20)) # закрашиваем прошлую пикчу
                pygame.draw.rect(screen, 'yellow', (self.gh_x + 7, self.gh_y + 7, 4, 4)) #рисуем монетку
                self.gh_x -= 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y)) # двигаем пикчу
                self.g_t_x -= 1
            elif dest == 1:  # вверх
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20))
                pygame.draw.rect(screen, 'yellow', (self.gh_x + 7, self.gh_y + 7, 4, 4))
                self.gh_y -= 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y))
                self.g_t_y -= 1
            elif dest == 2:  # вправо
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20))
                pygame.draw.rect(screen, 'yellow', (self.gh_x + 7, self.gh_y + 7, 4, 4))
                self.gh_x += 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y))
                self.g_t_x += 1
            elif dest == 3:  # вниз
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20))
                pygame.draw.rect(screen, 'yellow', (self.gh_x + 7, self.gh_y + 7, 4, 4))
                self.gh_y += 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y))
                self.g_t_y += 1
        elif dot_or_blk == 2:  # если без монетки
            if dest == 0:
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20))
                self.gh_x -= 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y))
                self.g_t_x -= 1
            elif dest == 1:
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20))
                self.gh_y += 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y))
                self.g_t_y += 1
            elif dest == 2:
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20))
                self.gh_x += 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y))
                self.g_t_x += 1
            elif dest == 3:
                pygame.draw.rect(screen, (0, 0, 0), (self.gh_x, self.gh_y, 20, 20))
                self.gh_y -= 20
                screen.blit(ghost_pink, (self.gh_x, self.gh_y))
                self.g_t_y -= 1
        elif dot_or_blk == 1:  # сли стена
            return False



def load_image(name, colorkey=None):
    fullname = os.path.join(name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image


if __name__ == '__main__':
    pygame.init()
    a = 10
    k = 1
    MOVEEVENT, t, trail = pygame.USEREVENT + 1, 15000, []
    GHOSTEVENT, t1 = pygame.USEREVENT + 2, 1
    pygame.time.set_timer(MOVEEVENT, t)
    pygame.time.set_timer(GHOSTEVENT, t1)
    fps = 100
    player = Ball(10, 270, 460, 23, 13)
    ghost = Ghost(270, 460, 23, 13, 20, 20, 1, 1)
    napravlenie = [False, False, False, False]  # 0 - left, 1 - up, 2 - right, 3 - down
    size = width, height = 560, 620
    screen = pygame.display.set_mode(size)
    # поле 5 на 7
    running = True
    screen.fill((0, 0, 0))
    l = Labirint
    pl_t_x = 13
    pl_t_y = 23
    pl_x = 272
    pl_y = 462
    t = 0.1
    v = 60
    p_gh_y = 240  # оложение розового по у
    p_gh_x = 320  # положение розового по х
    cursor_image = load_image("data/лабиринт.jpg")
    pacman_up = pygame.sprite.Sprite()
    pacman_dw = pygame.sprite.Sprite()
    pacman_lft = pygame.sprite.Sprite()
    pacman_r = pygame.sprite.Sprite()
    pacman_up = pygame.image.load('data/pacman_up.png')
    pacman_dw = pygame.image.load('data/pacman_dw.png')
    pacman_lft = pygame.image.load('data/pacman_lft.png')
    pacman_r = pygame.image.load('data/pacman_r.png')
    ghost_mgnt = pygame.sprite.Group()
    ghost_orng = pygame.sprite.Group()
    ghost_pink = pygame.sprite.Group()
    ghost_red = pygame.sprite.Group()
    ghost_orng = pygame.image.load('data/ghosts_orng.png')
    ghost_mgnt = pygame.image.load('data/ghosts_mgnt.png')
    ghost_pink = pygame.image.load('data/ghosts_pink.png')
    ghost_red = pygame.image.load('data/ghosts_red.png')
    cursor = pygame.sprite.Sprite(fon)
    cursor.image = cursor_image
    cursor.rect = pygame.Rect(0, 0, 560, 620)
    clock = pygame.time.Clock()
    fon.draw(screen)
    monety = 0
    for i in range(len(T)):
        for j in range(len(T[i])):
            if T[i][j] == 1:
                l = Labirint(i, j)
            elif T[i][j] == 0:
                pygame.draw.rect(screen, "yellow", (20 * j + 8, 20 * i + 8, 4, 4))
                monety += 1
    while running:
        pygame.time.delay(50)
        ghost.move()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == MOVEEVENT and a == 10:
                ghost.appearing()
                a -= 10
            if event.type == GHOSTEVENT and k == 1:
                k -= 10
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    napravlenie[0] = True
                    player.move()
                    napravlenie[0] = False
                if event.key == pygame.K_RIGHT:
                    napravlenie[2] = True
                    player.move()
                    napravlenie[2] = False
                if event.key == pygame.K_UP:
                    napravlenie[1] = True
                    player.move()
                    napravlenie[1] = False
                if event.key == pygame.K_DOWN:
                    napravlenie[3] = True
                    player.move()
                    napravlenie[3] = False
            if monety == 0:
                running = False
        pygame.display.flip()
    pygame.quit()
